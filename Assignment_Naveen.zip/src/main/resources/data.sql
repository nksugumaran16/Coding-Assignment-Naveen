DROP TABLE  IF EXISTS  Palindromes; 

create table Palindromes (
   id INT AUTO_INCREMENT  PRIMARY KEY,
   transaction_date date NOT NULL,
   palindrome VARCHAR(250) NOT NULL
  
    
  
);
